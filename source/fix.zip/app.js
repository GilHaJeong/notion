const Runtime = window.OratorioRuntime;

const contractState = {
  part: Runtime.normalizePart(localStorage.getItem("oratorio.v1.user.part")),
  subpart: localStorage.getItem("oratorio.v1.user.subpart") || "all",
  screen: "first_run_part_select",
  selectedSong: "NO09",
  selectedMeasure: "153~156",
  selectedFilter: "all"
};

const songs = Runtime.buildPublicSongs();

const copy = {
  readiness: {
    not_started: "시작 전",
    listening: "듣는 중",
    repeating: "반복 중",
    nearly_stable: "거의 안정",
    ready: "준비됨"
  },
  part: {
    S: "소프라노",
    A: "알토",
    T: "테너",
    B: "베이스"
  },
  firstRun: {
    next: "다음",
    disabled: "파트를 먼저 골라 주세요"
  }
};

const routeButtons = document.querySelectorAll("[data-route]");
const screens = document.querySelectorAll(".screen");
const tabs = document.querySelectorAll(".tab");
const partButtons = document.querySelectorAll(".part-button");
const subpartButtons = document.querySelectorAll(".subpart-button");
const filters = document.querySelectorAll(".filter");
const songList = document.querySelector("#songList");
const roleNotice = document.querySelector("#roleNotice");
const conductorPending = document.querySelector("#conductorPending");
const riskDialog = document.querySelector("#riskDialog");
const tabletShell = document.querySelector(".tablet-shell");
const subpartRow = document.querySelector(".subpart-row");
const firstRunNext = document.querySelector("#firstRunNext");

function saveUserState() {
  localStorage.setItem("oratorio.v1.meta.schemaVersion", "1");
  localStorage.setItem("oratorio.v1.user.part", contractState.part);
  localStorage.setItem("oratorio.v1.user.subpart", contractState.subpart);
}

function routeTo(screenId) {
  contractState.screen = screenId;
  screens.forEach((screen) => screen.classList.toggle("active", screen.id === screenId));
  tabs.forEach((tab) => tab.classList.toggle("active", tab.dataset.target === screenId));
  tabletShell.dataset.screen = screenId;
  updateTexture(contractState.part);
}

function updateTexture(part) {
  const texture = Runtime.textureFor(contractState.screen, part);
  document.querySelector(".texture-cloud").classList.toggle("is-visible", texture === "cloud");
  document.querySelector(".texture-dak").classList.toggle("is-visible", texture === "dak");
  document.querySelector(".texture-laid").classList.toggle("is-visible", texture === "laid");
}

function updatePartButtons() {
  partButtons.forEach((button) => {
    button.classList.toggle("active", button.dataset.part === contractState.part);
    button.setAttribute("aria-pressed", String(button.dataset.part === contractState.part));
  });

  const hasPart = contractState.part !== "none";
  const partName = copy.part[contractState.part] || "내 파트";
  subpartRow.hidden = !hasPart;
  firstRunNext.disabled = !hasPart;
  firstRunNext.textContent = hasPart ? copy.firstRun.next : copy.firstRun.disabled;
  subpartButtons.forEach((button) => {
    const label = button.dataset.subpart === "all" ? `${partName} 전체` : `${partName}${button.dataset.subpart}`;
    button.textContent = label;
    button.classList.toggle("active", button.dataset.subpart === contractState.subpart);
  });
}

function statusLabel(song) {
  const base = copy.readiness[song.status] || "상태 확인";
  return song.needsFocus ? `${base} · 집중 필요` : base;
}

function songRowTarget() {
  return window.matchMedia("(min-width: 768px)").matches ? "song_detail" : "practice";
}

function renderSongs() {
  const filtered = songs.filter((song) => {
    if (contractState.selectedFilter === "focus") return song.needsFocus;
    if (contractState.selectedFilter === "ready") return song.status === "ready" || song.status === "nearly_stable";
    return true;
  });

  songList.replaceChildren();

  if (filtered.length === 0) {
    const empty = document.createElement("p");
    empty.className = "panel";
    empty.textContent = "해당하는 곡이 없습니다.";
    songList.append(empty);
    return;
  }

  filtered.forEach((song) => {
    const row = document.createElement("button");
    row.type = "button";
    row.className = `song-row${song.needsFocus ? " needs-focus" : ""}`;
    row.innerHTML = `<span>No.${String(song.no).padStart(2, "0")} ${song.title}</span><small>${statusLabel(song)}</small>`;
    row.addEventListener("click", () => {
      selectSong(song);
      routeTo(songRowTarget());
    });
    songList.append(row);
  });
}

function updatePracticeTitle(song) {
  const practiceTitle = document.querySelector("#practice-title");
  const songDetailTitle = document.querySelector("#song-detail-title");
  const title = `No.${String(song.no).padStart(2, "0")} ${song.title}`;
  practiceTitle.textContent = title;
  songDetailTitle.textContent = title;
  document.querySelector("#songDetailPractice").textContent = Runtime.practiceActionLabel(contractState.selectedMeasure);
}

function selectSong(song) {
  contractState.selectedSong = song.id;
  contractState.selectedMeasure = song.segment;
  updatePracticeTitle(song);
}

routeButtons.forEach((button) => {
  button.addEventListener("click", () => {
    if (button.dataset.song) {
      const song = songs.find((item) => item.id === button.dataset.song);
      if (song) selectSong(song);
    }
    routeTo(button.dataset.route);
  });
});

tabs.forEach((tab) => {
  tab.addEventListener("click", () => routeTo(tab.dataset.target));
});

partButtons.forEach((button) => {
  button.addEventListener("click", () => {
    contractState.part = button.dataset.part;
    contractState.subpart = "all";
    saveUserState();
    updatePartButtons();
    updateTexture(contractState.part);
  });
});

subpartButtons.forEach((button) => {
  button.addEventListener("click", () => {
    contractState.subpart = button.dataset.subpart;
    saveUserState();
    updatePartButtons();
  });
});

filters.forEach((button) => {
  button.addEventListener("click", () => {
    contractState.selectedFilter = button.dataset.filter;
    filters.forEach((filter) => filter.classList.toggle("active", filter === button));
    renderSongs();
  });
});

document.querySelectorAll(".segment-row").forEach((button) => {
  button.addEventListener("click", () => {
    document.querySelectorAll(".segment-row").forEach((row) => row.classList.remove("selected"));
    button.classList.add("selected");
    contractState.selectedMeasure = button.dataset.measure;
    document.querySelector("#songDetailPractice").textContent = Runtime.practiceActionLabel(button.dataset.measure);
  });
});

conductorPending.addEventListener("click", () => {
  roleNotice.hidden = false;
  window.setTimeout(() => {
    roleNotice.hidden = true;
  }, 2600);
});

document.querySelector("#showRisks").addEventListener("click", () => riskDialog.showModal());
document.querySelector("#closeRisks").addEventListener("click", () => riskDialog.close());
firstRunNext.addEventListener("click", () => {
  if (contractState.part !== "none") routeTo("home");
});

updatePartButtons();
updateTexture(contractState.part);
renderSongs();
