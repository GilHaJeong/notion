const fs = require("fs");
const path = require("path");
const runtime = require("./runtime-logic.js");

const root = __dirname;
const errors = [];
const warnings = [];

function readJson(relativePath) {
  return JSON.parse(fs.readFileSync(path.join(root, relativePath), "utf8"));
}

function exists(relativePath) {
  return fs.existsSync(path.join(root, relativePath));
}

function collectScreenIds() {
  const indexHtml = fs.readFileSync(path.join(root, "index.html"), "utf8");
  return new Set([...indexHtml.matchAll(/<section id="([^"]+)"/g)].map((match) => match[1]));
}

function validateRuntimeLogic() {
  const publicSongs = runtime.buildPublicSongs();
  const songIds = new Set(publicSongs.map((song) => song.id));

  if (publicSongs.length !== 20) errors.push(`Expected 20 public runtime songs, found ${publicSongs.length}.`);
  if (songIds.size !== publicSongs.length) errors.push("Runtime song inventory contains duplicate IDs.");
  if (runtime.normalizePart(null) !== "none") errors.push("First-run part must default to none.");
  if (runtime.normalizePart("invalid") !== "none") errors.push("Invalid stored part must reset to none.");
  if (runtime.practiceActionLabel(null) !== "처음부터 연습하기") {
    errors.push("From-start practice action must use the canonical copy.");
  }
  if (runtime.textureFor("home", "T") !== null) {
    errors.push("Undecided top-level screen textures must remain hidden.");
  }
  if (runtime.textureFor("first_run_part_select", "T") !== "dak") {
    errors.push("Tenor first-run texture must map to dak fiber.");
  }
  if (runtime.textureFor("first_run_part_select", "S") !== "laid") {
    errors.push("Soprano first-run texture must map to laid lines.");
  }
}

function validateDataFiles() {
  const songsData = readJson("data/songs.json");
  const mediaData = readJson("data/media.json");
  const syncData = readJson("data/score-sync.json");
  const cuesData = readJson("data/cues.json");
  const songIds = new Set();

  if (songsData.songs.length !== 36) {
    errors.push(`Expected 36 songs, found ${songsData.songs.length}.`);
  }

  for (const song of songsData.songs) {
    if (songIds.has(song.song_id)) errors.push(`Duplicate song_id: ${song.song_id}`);
    songIds.add(song.song_id);
    if (!/^no-\d{2}$/.test(song.song_id)) errors.push(`Invalid song_id format: ${song.song_id}`);
  }

  for (const media of mediaData.media) {
    if (!songIds.has(media.song_id)) errors.push(`Media references unknown song_id: ${media.song_id}`);
  }

  for (const cue of cuesData.cues) {
    if (!songIds.has(cue.song_id)) errors.push(`Cue references unknown song_id: ${cue.song_id}`);
  }

  const cueIds = new Set(cuesData.cues.map((cue) => cue.cue_id));
  for (const point of syncData.score_sync) {
    if (!songIds.has(point.song_id)) errors.push(`Score sync references unknown song_id: ${point.song_id}`);
    for (const key of ["x", "y", "w", "h"]) {
      const value = point.hotspot?.[key];
      if (typeof value !== "number" || value < 0 || value > 1) {
        errors.push(`Invalid hotspot ${key} for ${point.song_id} at ${point.measure}.`);
      }
    }
    for (const cueId of point.cue_ids || []) {
      if (!cueIds.has(cueId)) errors.push(`Score sync references unknown cue_id: ${cueId}`);
    }
  }

  for (const required of ["no-06", "no-09"]) {
    if (!mediaData.media.some((media) => media.song_id === required)) {
      errors.push(`Missing required sample media for ${required}.`);
    }
    if (!syncData.score_sync.some((point) => point.song_id === required)) {
      errors.push(`Missing required score sync for ${required}.`);
    }
  }

  const pendingTitles = songsData.songs.filter((song) => song.source_status === "pending_canonical_title").length;
  if (pendingTitles > 0) warnings.push(`${pendingTitles} canonical song titles still need confirmation.`);
}

function validateUiContract() {
  const contract = readJson("contracts/ui-v0.4.2-implementation-snapshot.json");
  const screenIds = collectScreenIds();
  const html = fs.readFileSync(path.join(root, "index.html"), "utf8");
  const css = fs.readFileSync(path.join(root, "styles.css"), "utf8");
  const app = fs.readFileSync(path.join(root, "app.js"), "utf8");

  for (const file of ["index.html", "styles.css", "runtime-logic.js", "app.js"]) {
    if (!exists(file)) errors.push(`Missing runtime file: ${file}`);
  }

  for (const screenId of contract.screens.required) {
    if (!screenIds.has(screenId)) errors.push(`Missing screen section: ${screenId}`);
  }

  const touchTarget = Number(css.match(/--touch:\s*(\d+)px/)?.[1]);
  if (touchTarget !== 56) errors.push("Tablet touch target token must be 56px.");
  if (!css.includes("font-size: 18px")) {
    warnings.push("Body 18px appears absent from CSS; tablet senior readability must be manually checked.");
  }
  if (!css.includes("max-width: 1180px")) {
    warnings.push("820x1180 is represented via responsive shell; add screenshot validation for exact viewport.");
  }

  if (!html.includes('id="firstRunNext" class="primary-action" type="button" disabled')) {
    errors.push("First-run next action must be disabled before part selection.");
  }
  if (/<button[^>]*class="part-button active"/.test(html)) {
    errors.push("First-run markup must not preselect a part.");
  }
  if (!html.includes('data-route="practice" data-song="NO06"')) {
    errors.push("Home No.6 practice action must hand off its song ID.");
  }
  if (html.indexOf('src="runtime-logic.js"') > html.indexOf('src="app.js"')) {
    errors.push("Runtime logic must load before the application script.");
  }
  if (!css.includes("--texture-cloud-image") || !css.includes("--texture-dak-image") || !css.includes("--texture-laid-image")) {
    errors.push("Canonical texture asset swap points are missing.");
  }
  if (/\.texture-(?:cloud|dak|laid)\s*\{[^}]*gradient/s.test(css)) {
    errors.push("Texture layers must not substitute generated gradients for canonical assets.");
  }

  for (const key of contract.storage.requiredKeys) {
    if (!app.includes(key)) errors.push(`Missing storage key usage: ${key}`);
  }

  for (const gap of contract.contractGaps) {
    if (!gap.reported) warnings.push(`Unreported contract gap: ${gap.id}`);
  }


  warnings.push("Canonical texture assets are referenced from Notion and are not bundled for offline verification.");
  warnings.push("Browser viewport, media playback, and real-score readability checks have not run in this validator.");

  return contract;
}

validateDataFiles();
validateRuntimeLogic();
const contract = validateUiContract();

const report = {
  last_checked: new Date().toISOString(),
  status: errors.length ? "failed" : "static_checks_passed",
  validation_status: errors.length ? "FAIL" : "PARTIAL",
  contract: contract.meta,
  gate: {
    contract_bundle_identification: "CONFIRMED",
    current_implementation_approval: "NOT_GRANTED",
    release: "BLOCK"
  },
  errors,
  warnings,
  next_required: [
    "Opus 5 contract update for the seven tracked contract gaps.",
    "Bundle canonical texture assets into the stable artifact store.",
    "Tablet viewport visual QA at 820x1180, 768x1024, 834x1194, and 1024x1366.",
    "No.9 printed score page 50 readability check at 70-90cm."
  ]
};

fs.writeFileSync(path.join(root, "data/validation/report.json"), `${JSON.stringify(report, null, 2)}\n`);

if (errors.length) {
  console.error(JSON.stringify(report, null, 2));
  process.exit(1);
}

console.log(JSON.stringify(report, null, 2));
