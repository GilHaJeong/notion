# Notion Baseline Import

## Source Project

- Project: 오라토리오 「성령이 교회들에게 하시는 말씀」 초연
- Event: 창립 49주년 찬양예배 초연
- Reference date: 2026-10-04
- Primary workflow: 정본-게이트 기반 연속체 워크플로우
- Preservation rule: 중복 금지, 정본 고정, 게이트 통과

## Imported Work Structure

| Notion 영역 | Work Mode 편입 형태 | 현재 처리 |
|---|---|---|
| 진행 로그 인덱스 | `docs/progress-log.md` | 로그 체계 반영 |
| 리허설 웹앱 프로젝트 | `README.md`, `index.html`, `data/*` | 실행 골격 생성 |
| 대시보드 UI 개발 채팅 | `index.html`, `app.js`, `styles.css` | 태블릿 우선 조건부 구현 반영 |
| 데이터 패키지 규격 | `data/songs.json`, `data/media.json` | 초기 계약 생성 |
| Cue/Sync 구조 | `data/cues.json`, `data/score-sync.json` | 샘플 계약 생성 |
| 검수 기록 | `validate-data.js`, `data/validation/report.json` | 자동 검증 시작 |

## Progress Snapshot

| 구분 | Notion 기준 |
|---|---:|
| 전체 진척 | 약 43% |
| 기획·개념 설계 | 82% |
| 정보 구조·데이터 설계 | 68% |
| UI·UX 설계 | 48% |
| 콘텐츠 패키지 | 38% |
| 실제 구현 | 12% |
| 검수·배포 | 28% |

## Immediate Build Direction

1. 대원용 태블릿 우선 화면 골격을 먼저 고정한다.
2. No.6 and No.9 player-score sample flow를 만든다.
3. Laodicea cue mini prototype을 만든다.
4. `score_sync` equivalent data contract를 검증 가능하게 둔다.
5. Gate를 통과한 뒤 36곡 전체 확장으로 넘어간다.

## Lineage Execution Note

| 계보상 위치 | Work Mode 실행 위치 | 실제 수행 행위 |
|---|---|---|
| GPT-5.5 Thinking | 운영 기준·통합 보고자 | 판단 기준, 기록 체계, 단계 승인 |
| Codex | 실행 대행 | 파일 생성, 검증, 산출물 구성 |
| GPT-5.6 Sol | 후대 구현 검토 | 앱 구조, 컴포넌트, 데이터 흐름 제안 |
| GPT-5.6 Terra | 후대 데이터 검토 | 36곡 ID, sync, validation 기준 제안 |
| GPT-5.6 Luna | 후대 UX 검토 | 대원용 문구, 모바일 흐름 제안 |
| GPT-6 Astra | 미래 후대 검토 | 정본 보존, 게이트, 확장 방향 점검 |
