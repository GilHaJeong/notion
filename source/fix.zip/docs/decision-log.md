# Decision Log

## D-001: Preserve Notion As Canonical Source

- Decision: Notion remains the source of truth.
- Work project role: executable scaffold and validation layer.
- Reason: prevent duplicated or conflicting canonical structure.

## D-002: Score Implementation Starts With PDF Image + Hotspot Overlay

- Decision: start with A-option implementation while keeping C-option expansion open.
- Initial form: score image plus normalized hotspot overlay.
- Later expansion: SVG overlay or richer interactive score layer.

## D-003: User UI Uses Rehearsal Language

- Decision: avoid exposing internal terms such as dashboard, sync, cue, schema, session.
- User-facing equivalents:
  - Dashboard -> 오늘은 여기부터
  - Cue -> 시작 안내 / 들어갈 차례
  - Sync -> 연습 위치
  - Player -> 연습 화면

## D-004: Gate Before Full Expansion

- Decision: No.6, No.9, and Laodicea samples must pass validation before 36-song expansion.
- Gate conditions:
  - stable song IDs
  - valid sample media references
  - valid normalized hotspots
  - visible tablet action flow
  - clear user copy

## D-005: Shift Primary UI Target To Tablet

- Decision: the rehearsal app now uses tablet portrait as the primary design target.
- Primary viewport: 820x1180.
- Verification viewports: 768x1024, 834x1194, 1024x1366.
- Reason: most choir members are age 60+, and smartphone score rehearsal has low practical value.

## D-006: OpenAI GPT Execution Replaces Notion GPT Execution

- Decision: implementation execution moves to OpenAI GPT/Codex workflow.
- Notion role: canonical contract and progress record.
- Codex role: fast executable implementation, validation, packaging, and issue reporting.
- Reason: Notion page-to-page execution autonomy limits speed.

## D-007: Contract Conditions Are Speed-Optimized And User-Governed

- Decision: existing contract constraints are interpreted as progress-speed optimization conventions.
- Final authority: 설계자님.
- Operation rule: if a faster safe condition is found, report impact, risk, and recommended contract change before treating it as final.

## D-008: Conditional Tablet Implementation Baseline

- Decision: proceed with a conditional tablet-first implementation baseline.
- Allowed now: screen skeleton, state model, local storage keys, sample flows, validation report.
- Still blocked: release and full expansion until contract gaps and real score readability checks are resolved.

## D-009: Separate Static Validation From Approval

- Decision: passing syntax, data, and pure runtime checks does not grant current implementation approval.
- Current implementation approval: NOT GRANTED.
- Release: BLOCK.
- Reason: browser viewport, media, real-score readability, and unresolved contract gaps remain outside the static evidence.

## D-010: Correct Only Contract-Determinate Deviations

- Decision: fix the first-run none state, disabled progression, texture isolation, No.6 handoff, canonical from-start copy, and public-song inventory without resolving the seven open contract gaps in code.
- Open issues remain visible and return to the Notion decision process.
