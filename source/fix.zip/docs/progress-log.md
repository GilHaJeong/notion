# Progress Log

## 2026-09-18

### Scope

Bring the 20-30% plus partially advanced Notion work structure into the current Work Mode project without breaking canonical source structure.

### Current State

Executable scaffold created:

- Notion baseline document
- Decision log
- Initial 36-song ID inventory
- No.6 and No.9 rehearsal samples
- Laodicea start-guide sample
- Previous mobile action-first home prototype
- Data validation script

### Next Action

Replace placeholder score/audio assets with confirmed source files, then run the No.6 and No.9 rehearsal flow through a real playback test.

### Tablet-First Execution Update

Execution direction changed from smartphone-first rehearsal to tablet-first rehearsal because the primary users are senior choir members.

Completed in the local executable baseline:

- Replaced the previous mobile action-first prototype with a tablet-first single-page flow.
- Added `first_run_part_select`, `home`, `song_detail`, `progress_all`, and `practice` screens.
- Added part/subpart persistence through `oratorio.v1.*` local storage keys.
- Added a contract status panel and seven tracked contract gaps.
- Expanded validation so data and UI contract basics are checked together.

Current gate:

- Contract identification: PASS
- Implementation start: CONDITIONAL PASS
- Release: BLOCK

Immediate next action:

Run visual QA for tablet viewports and confirm No.9 page 50 printed-score readability at 70-90cm with real score assets.

### G-003 Correction Update

Completed contract-determinate corrections:

- Removed the preselected tenor state; first run now starts with `part=none`.
- Hid subpart controls and disabled progression until a part is selected.
- Isolated undecided texture layers to the first-run screen and replaced generated texture substitutes with canonical asset swap points.
- Added No.6 song-state handoff and canonical `처음부터 연습하기` formatting.
- Represented the 36-song structure as 20 public runtime rows plus 16 locked songs.
- Added pure runtime tests for state, copy, texture, and inventory rules.
- Removed fixed `PASS` / `CONDITIONAL_PASS` approval output from the validator.

Current evidence:

- Static checks: passed.
- Validation status: PARTIAL.
- Current implementation approval: NOT GRANTED.
- Release: BLOCK.

Remaining evidence:

- Canonical texture files bundled in stable storage.
- Browser QA at all four tablet viewports.
- Real media playback.
- No.9 page 50 readability at 70-90cm.
