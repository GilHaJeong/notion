# UI v0.4.2 Execution Report

## Summary

OpenAI GPT/Codex execution converted the local prototype from smartphone-first rehearsal to a tablet-first conditional implementation baseline.

## Implemented

- Tablet-first layout with 56px touch target token.
- Body copy baseline at 18px for senior choir readability.
- Required screen skeletons:
  - `first_run_part_select`
  - `home`
  - `song_detail`
  - `progress_all`
  - `practice`
- Part and subpart local persistence:
  - `oratorio.v1.meta.schemaVersion`
  - `oratorio.v1.user.part`
  - `oratorio.v1.user.subpart`
- Sample flows for No.6 and No.9.
- Contract panel exposing the seven known contract gaps.
- Combined validation script for data and UI contract basics.

## Known Contract Gaps

| ID | Status | Needed Decision |
|---|---|---|
| `type-token-tablet-body` | Reported | Map canonical type tokens to tablet 18-20px acceptance. |
| `progress-song-row-routing` | Reported | Decide whether tablet song row opens `song_detail` or `practice`. |
| `role-slot-blocks` | Reported | Align roleSlot definition across home, progress, and detail screens. |
| `song-detail-initial-segment` | Reported | Replace descriptive initial value with null or a concrete segment ID. |
| `practice-score-width` | Reported | Clarify whether practice score may exceed 640px content width. |
| `practice-return-target` | Reported | Align backLink behavior with `return_target`. |
| `phone-score-not-recommended-copy` | Reported | Add user-facing phone score-practice limitation copy. |

## Gate

| Gate | Result |
|---|---|
| Contract bundle identification | CONFIRMED |
| Static validation | PARTIAL |
| Current implementation approval | NOT GRANTED |
| Release | BLOCK |

The earlier `CONDITIONAL PASS` remains historical evidence from G-001/G-002. It is not a current-round approval.

## Next Execution

1. Run viewport QA at 820x1180, 768x1024, 834x1194, and 1024x1366.
2. Replace placeholder score frame with real No.9 page 50 asset.
3. Verify score readability at 70-90cm.
4. Ask 설계자님 whether to revise contract conditions for faster tablet execution.
