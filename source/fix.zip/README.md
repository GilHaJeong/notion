# Oratorio Rehearsal Tablet Prototype

This project is the executable Work Mode baseline for
`오라토리오 「성령이 교회들에게 하시는 말씀」` 대원용 리허설 웹앱.

## Operating Rule

- Notion remains the canonical source and contract record.
- This repository is the executable prototype, validation layer, and handoff package.
- The active UI direction is tablet-first for senior choir members.
- Phone support is secondary and should cover home, progress, and audio rehearsal only.
- Release remains blocked until printed-score readability is verified with real score assets.

## Current Scope

- Tablet-first single-page prototype.
- Required screens:
  - `first_run_part_select`
  - `home`
  - `song_detail`
  - `progress_all`
  - `practice`
- Local state persistence for part and subpart selection.
- Contract-risk panel for the seven known Notion contract gaps.
- No.6 and No.9 sample rehearsal paths.
- 36-song data inventory and validation report.

## Gate Status

| Gate | Status | Meaning |
|---|---|---|
| Contract bundle identification | CONFIRMED | The designated version combination is identified. |
| Static validation | PARTIAL | Data, syntax, and pure runtime rules pass; browser and real-score checks remain. |
| Current implementation approval | NOT GRANTED | Historical conditional passes do not extend to the current round. |
| Release | BLOCK | Real tablet visual QA and score readability evidence are still required. |

## Local Preview

Open `index.html` in a browser, or serve the folder with a static server.

```bash
python3 -m http.server 4173
```

Then open `http://localhost:4173`.

## Validation

Run:

```bash
node validate-data.js
node --check runtime-logic.js
node --check app.js
```

The validation output is written to `data/validation/report.json`.

## Contract Snapshot

`contracts/ui-v0.4.2-implementation-snapshot.json` records the implementation baseline, required screens, storage keys, tablet acceptance criteria, and known contract gaps.
