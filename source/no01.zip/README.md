# NO01 · MusicXML 성부별 MIDI 연습기

가창 생성은 중단하고, `NO01_omr_proposed_full.musicxml`의 후보 음표 이벤트를 기준으로 Tenor solo와 Piano를 분리한 MIDI 수준 control stem을 재생하는 정적 웹앱입니다.

## 실행

```bash
python3 -m http.server 8000
```

그 다음 `http://localhost:8000/`을 엽니다.

## 포함 내용

- `index.html`: 성부별 재생·믹스·음소거·seek·이벤트 타임라인
- `audio/`: tenor, piano, mix WAV
- `data/events.json`: MusicXML-derived 이벤트
- `data/manifest.json`: provenance·해시·제한
- `assets/`: PDF 근거 캡처

## 제한

- 후보 MusicXML은 canonical이 아닙니다.
- 음원은 sine/additive MIDI-level synth이며 실제 가창·performer·voicebank 음원이 아닙니다.
- MusicXML 후보의 음표·피아노 보이싱 이상 가능성을 그대로 보존합니다.
